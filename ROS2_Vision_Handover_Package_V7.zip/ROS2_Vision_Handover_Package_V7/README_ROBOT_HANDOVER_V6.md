# 🤖 TÀI LIỆU BÀN GIAO TOÀN DIỆN CHO ĐỘI NGŨ ROBOT & ROS 2 (PHIÊN BẢN V6)

Tài liệu này hướng dẫn đội ngũ **Robot Navigation / ROS 2 / Embedded** tích hợp toàn diện hệ thống **AI 2-Stage Vision** và **Bộ Đồng Bộ Telemetry Realtime** với Backend .NET và Staff Web/Mobile App cho hệ thống **SuperMarketBot**.

---

## 1. 📦 Các Tệp Cốt Lõi Trong Gói Bàn Giao V6

| Tệp / Thư mục | Định dạng | Chức năng chính |
|---|---|---|
| **`shelf_sweep_telemetry_node.py`** | **ROS 2 Python Node (MỚI)** | Node ROS 2 tối ưu: Tự động gom buffer khi robot lia ngang qua kệ $\to$ Chọn Best Frame nét nhất có tem ArUco $\to$ Chạy AI nhận diện $\to$ Bắn Telemetry & Báo cáo mật độ lên MQTT |
| **`shelf_vision.py`** | Python Engine | Lõi AI Vision 2-Stage: Lọc biên kệ (`Boundary Guard`), bóc tách chồng tầng (`Stack Decomposition`), ghép mảnh chai (`Vertical Merge`), phân chia T1/T2 |
| **`product_matcher.py`** | Python Engine | Trích xuất đặc trưng MobileNetV3 (vector 576 chiều) & Cosine Similarity so khớp 31 SKU |
| **`best.pt`** & **`best.onnx`** | PyTorch / ONNX (YOLOv8) | Mô hình phát hiện bounding box hàng hóa (`product`) và slot trống (`empty_slot`) |
| **`reference_products/`** | Thư mục ảnh mẫu | Bộ 83 ảnh mẫu tham chiếu đã được hiệu chuẩn cho cả **6 Kệ Hàng** |
| **`aruco_tags/`** | Thư mục tem SVG / PNG | Bộ tem ArUco Tag (Dictionary `DICT_4X4_50`, Tag #1 đến #6) dán tại mép cột kệ |

---

## 2. 🎯 Logic 1: Thuật Toán Lia Ngang & Tự Động Chọn Best Frame (Sweep Buffer)

### Vấn đề thực tế của Robot:
Khi robot dừng trước kệ bằng thuật toán điều hướng Nav2 (AMCL/SLAM), robot thường có sai số vị trí ($\pm 10\text{--}20\text{ cm}$) hoặc dừng lệch góc, dẫn đến camera bị khuất một phần kệ hoặc ảnh bị nhòe do quán tính phanh.

### Giải pháp V6 tích hợp sẵn trong `shelf_sweep_telemetry_node.py`:
1. Khi robot di chuyển chậm ngang qua kệ ($0.1 - 0.2\text{ m/s}$), phát lệnh kích hoạt sweep qua topic:
   - **Topic:** `/shelf/sweep/trigger`
   - **Payload:** `{"shelfId": 4, "duration": 2.0}`
2. Node sẽ thu thập liên tục 10–15 frames trong $2.0\text{s}$, đồng thời tính điểm cho từng frame:
   $$\text{Score} = (\text{Diện tích ArUco Tag} + 1.0) \times \text{Độ nét Laplacian } (\nabla^2 I)$$
3. Node tự động chọn **1 Best Frame** có điểm số cao nhất (nét nhất, góc trực diện nhất, tem ArUco lớn nhất) để đưa vào mô hình nhận diện AI, loại bỏ hoàn toàn các khung hình rung lắc.

---

## 3. 📍 Logic 2: Gói Tin MQTT Telemetry (Hiển Thị Realtime Lên Staff Map HUD)

Để hiển thị vị trí, mức pin, góc xoay và trạng thái của Robot lên bản đồ nhân viên (`/staff/map`), Node tự động publish định kỳ **1.5 giây/lần**:

* **MQTT Broker:** `IP_BACKEND` (mặc định cổng `1883`)
* **Topic:** `smartmarketbot/robot/{robotCode}/telemetry` (Ví dụ: `smartmarketbot/robot/RB001/telemetry`)
* **Cấu trúc JSON:**
```json
{
  "robotCode": "RB001",
  "batteryPct": 95,
  "x": 1.90,
  "y": 0.20,
  "heading": 180.0,
  "status": "Scanning",
  "nearestShelf": "Kệ 4 - Mì Ăn Liền & Đóng Gói",
  "timestamp": 1725498000
}
```

* **Ý nghĩa các trường:**
  - `status`: Có thể là `"Idle"` (Đang chờ), `"Navigating"` (Đang di chuyển), `"Scanning"` (Đang quét kệ), `"Charging"` (Đang sạc pin).
  - `x`, `y`: Tọa độ mét trên bản đồ siêu thị (lấy từ `/odom` hoặc `/amcl_pose`).
  - `heading`: Góc xoay hướng đi của robot theo độ ($0^\circ - 360^\circ$).

---

## 4. 📦 Logic 3: Gói Tin Báo Cáo Kệ Hàng (Shelf Report Contract)

Sau khi sweep xong, Node tự động tính toán mật độ hàng hóa và gửi báo cáo về Backend qua MQTT:

* **Topic:** `smartmarketbot/robot/{robotCode}/shelf_report`
* **Cấu trúc JSON:**
```json
{
  "robotCode": "RB001",
  "shelfId": 4,
  "densityPercentage": 42.0,
  "emptyPercentage": 58.0,
  "isOutOfStock": true,
  "isLowStock": false,
  "totalObjects": 8,
  "totalEmptySlots": 6,
  "timestamp": "2026-09-05T01:10:00Z"
}
```

> **Chu trình khép kín tự động:**
> 1. Khi Backend nhận thấy `emptyPercentage > 30%` (hoặc `densityPercentage < 70%`), Backend tự động tạo bản ghi `SHELF_SCAN` có `NeedsRestock = true`.
> 2. Backend bắn SignalR realtime cảnh báo tới Staff App kèm âm thanh chuông báo.
> 3. Nhân viên xem thông báo `Dãy B01 · Kệ 4 - Mì Ăn Liền & Đóng Gói` (mật độ 42%), lấy hàng từ kho ra châm lên kệ.
> 4. Nhân viên bấm nút **`Xác nhận đã châm đầy hàng (Restocked)`** trên App $\to$ Backend cập nhật tồn kho `Quantity += 15`, đóng nhiệm vụ và ẩn thông báo.

---

## 5. 🏷️ Danh Mục 6 Kệ Hàng & 31 Mặt Hàng SKU Thực Tế

| Kệ | Danh mục thực tế | ArUco Tag | Dãy (Aisle) | Tọa độ Waypoint đề xuất |
|:---:|---|:---:|:---:|:---:|
| **Kệ 1** | Đồ Ăn Vặt & Bánh Kẹo Tết | **Tag #1** | Dãy A01 | Node #11 (X: 1.10, Y: 1.80) |
| **Kệ 2** | Nước Giải Khát & Đồ Uống | **Tag #2** | Dãy A01 | Node #12 (X: 1.10, Y: 1.00) |
| **Kệ 3** | Thực Phẩm Tươi Sống | **Tag #3** | Dãy B01 | Node #13 (X: 1.90, Y: 1.80) |
| **Kệ 4** | Mì Ăn Liền & Đóng Gói | **Tag #4** | Dãy B01 | Node #14 (X: 1.90, Y: 0.20) |
| **Kệ 5** | Đồ Gia Dụng & Tiện Ích | **Tag #5** | Dãy C01 | Node #15 (X: 2.70, Y: 1.80) |
| **Kệ 6** | Gia Vị & Trà Siêu Thị | **Tag #6** | Dãy C01 | Node #16 (X: 2.70, Y: 0.80) |

---

## 6. 🚀 Hướng Dẫn Chạy Node ROS 2

### Bước 1: Cài đặt thư viện trên máy tính Robot (Ubuntu / Jetson / Raspberry Pi 5)
```bash
pip install ultralytics opencv-python paho-mqtt torch torchvision cv-bridge
```

### Bước 2: Chạy Node ROS 2
```bash
python3 shelf_sweep_telemetry_node.py \
  --ros-args \
  -p robot_code:=RB001 \
  -p mqtt_broker:=192.168.1.100 \
  -p mqtt_port:=1883 \
  -p conf_threshold:=0.06
```

### Bước 3: Thử nghiệm kích hoạt sweep từ terminal
```bash
# Giả lập lệnh quét Kệ 4 trong 2 giây khi robot đi ngang qua
ros2 topic pub --once /shelf/sweep/trigger std_msgs/msg/String '{data: "{\"shelfId\": 4, \"duration\": 2.0}"}'

# Xem kết quả phân tích JSON xuất ra
ros2 topic echo /shelf/analysis
```
